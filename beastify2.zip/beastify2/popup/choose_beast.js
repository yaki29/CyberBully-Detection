/**
 * CSS to hide everything on the page,
 * except for elements that have the "beastify-image" class.
 */
const hidePage = `body > :not(.beastify-image) {
                    display: none;
                  }`;

/**
 * Listen for clicks on the buttons, and send the appropriate message to
 * the content script in the page.
 */

document.getElementById("myButton").addEventListener("click", myFunction);

var k;

function myFunction(){
    console.log('asd');
    // createCustomAlert(" ");
    const xhttp = new XMLHttpRequest();

    var url = "http://localhost:5000/?query=";
    var str = document.getElementById("textboxarea").value;

    // console.log(str);

    var i;
    var txt = ""
    // console.log(str.length);
    for (i = 0; i < str.length; i++) 
    {
        if(str[i] == ' ')
        {
            // console.log(txt);
            txt += '+';
            url += txt;
            txt = "";
        }
        else
            txt += str[i];
    }

    url += txt;

    console.log(url);

    // const url='http://localhost:5000/?query=aaj+achaa+din+he';
    xhttp.open("GET", url, false);
    xhttp.send();
    k = xhttp.responseText;
    
    console.log(k);

    var obj = JSON.parse(k);

    console.log(obj.data);

    if(obj.data == 1)
    {
        createCustomAlert(" ");
    }
}
var ALERT_TITLE = "THIS MESSAGE SEEMS DANGEROUS!";
var ALERT_BUTTON_TEXT = "Report It";
var safe="looks safe";

// if(document.getElementById) {
//     window.alert = function(txt) {
//         createCustomAlert(txt);
//     }
// }

function createCustomAlert(txt) {
    d = document;
// <button type="button">ok therer!</button>
    if(d.getElementById("modalContainer")) return;

    mObj = d.getElementsByTagName("body")[0].appendChild(d.createElement("div"));
    mObj.id = "modalContainer";
    mObj.style.height = d.documentElement.scrollHeight + "px";

    alertObj = mObj.appendChild(d.createElement("div"));
    alertObj.id = "alertBox";
    if(d.all && !window.opera) alertObj.style.top = document.documentElement.scrollTop + "px";
    alertObj.style.left = (d.documentElement.scrollWidth - alertObj.offsetWidth)/2 + "px";
    alertObj.style.visiblity="visible";

    h1 = alertObj.appendChild(d.createElement("h1"));
    h1.appendChild(d.createTextNode(ALERT_TITLE));

    msg = alertObj.appendChild(d.createElement("p"));
    //msg.appendChild(d.createTextNode(txt));
    msg.innerHTML = txt;

            btn = alertObj.appendChild(d.createElement("a"));
    btn.id = "closeBtn";
    btn.appendChild(d.createTextNode(ALERT_BUTTON_TEXT));
    // btn.appendChild(d.createTextNode(safe);
    btn.href = "#";
    btn.focus();
    btn.onclick = function() { removeCustomAlert();return false; }

//
    btn1 = alertObj.appendChild(d.createElement("a"));
    btn1.id = "closeBtn";
    btn1.appendChild(d.createTextNode(safe));
    // btn.appendChild(d.createTextNode(safe);
    btn1.href = "www.gmail.com";
    btn1.focus();
// <btn1.onclick="window.open('http://www.website.com/page')" />

    btn1.onclick = function() {
        console.log('aaaaa');
        // window.open("www.gmail.com");
        removeCustomAlert();return false;
    }
        // <button id="myButton">Click me</button>

    alertObj.style.display = "block";

}

function removeCustomAlert() {
    document.getElementsByTagName("body")[0].removeChild(document.getElementById("modalContainer"));
}
function ful(){
    alert('Alert this pages');
}